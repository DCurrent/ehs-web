THANK YOU FOR USING ApPHP software!
-----------------------------------------------------------------------------------

It's very easy to get started!!!

1. Installation:
-- (not updated) docs/install.html 
-- (updated) http://phpbuilder.awardspace.com/dgwiki/installation.htm

2. Getting started:
-- (not updated) docs/getting started.html 
-- (updated) http://phpbuilder.awardspace.com/dgwiki/getting_started.htm


