FormValudator = function () {

};

// tooltips
FormValudator._MSG = {};
FormValudator._MSG["MSG_1"] = "<_TITLE_OF_FIELD_> est requis!\n";
FormValudator._MSG["MSG_2"] = "<_TITLE_OF_FIELD_> est requis!\nEntrez une valeur coh�rente.";
FormValudator._MSG["MSG_3"] = "You have to sign <_TITLE_OF_FIELD_> box as checked!\n";
FormValudator._MSG["MSG_4"] = "<_TITLE_OF_FIELD_> doit �tre <_TYPE_OF_FIELD_>!\nRessaisissez, SVP.";
FormValudator._MSG["MSG_5"] = "<_TITLE_OF_FIELD_> doit �ter rempli par <_TYPE_OF_FIELD_>!\nRessaisissez, SVP."
        
FormValudator._MSG["SNT_1"] = "valeur";
FormValudator._MSG["SNT_2"] = "positive ";
FormValudator._MSG["SNT_3"] = "positive ou n�gative ";
FormValudator._MSG["SNT_4"] = "MAJUSCULE";
FormValudator._MSG["SNT_5"] = "positive ";
FormValudator._MSG["SNT_6"] = "negative ";
FormValudator._MSG["SNT_7"] = "Casse normale";
FormValudator._MSG["SNT_8"] = "minuscule";
FormValudator._MSG["SNT_9"] = "un ";
FormValudator._MSG["SNT_10"] = "_SYB_TYPE_OF_FIELD_ est un nombre";
FormValudator._MSG["SNT_11"] = "_SYB_TYPE_OF_FIELD_ est un entier";
FormValudator._MSG["SNT_12"] = "_SYB_TYPE_OF_FIELD_ est un r�el (flottant)";
FormValudator._MSG["SNT_13"] = "_SYB_TYPE_OF_FIELD_ est constitu� de lettre";
FormValudator._MSG["SNT_14"] = "_SYB_TYPE_OF_FIELD_ est constitu� d'un texte";
FormValudator._MSG["SNT_15"] = "_PASS_LENGTH_ doit contenir des lettres et de chiffres";
FormValudator._MSG["SNT_16"] = "_LOGIN_LENGTH_ doit commencer par une lettre ou un chiffre";
FormValudator._MSG["SNT_17"] = "est un code postale";
FormValudator._MSG['SNT_18'] = "est une adresse e-mail";
FormValudator._MSG['SNT_19'] = "_PASS_LENGTH_ trop court";
FormValudator._MSG['SNT_20'] = "type requis";
FormValudator._MSG['SNT_21'] = "est une URL valide";



